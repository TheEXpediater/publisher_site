<?php
/**
 * Plugin Name: Client Portal
 * Description: Enterprise 1979 Publisher Portal
 * Version: 1.0.0
 * Author: Alvin
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CP_PATH', plugin_dir_path(__FILE__));
define('CP_URL', plugin_dir_url(__FILE__));

require_once CP_PATH . 'includes/helpers.php';
require_once CP_PATH . 'includes/layout.php';
require_once CP_PATH . 'includes/auth.php';
require_once CP_PATH . 'includes/dashboard.php';
require_once CP_PATH . 'includes/users.php';
require_once CP_PATH . 'includes/articles.php';
require_once CP_PATH . 'includes/categories.php';
require_once CP_PATH . 'includes/settings.php';

function cp_enqueue_assets()
{
    wp_enqueue_style(
        'bootstrap-css',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'
    );

    wp_enqueue_style(
        'bootstrap-icons',
        'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css'
    );

    wp_enqueue_style(
        'cp-style',
        CP_URL . 'assets/css/style.css',
        [],
        '1.0'
    );

    wp_enqueue_style(
        'cp-login',
        CP_URL . 'assets/css/login.css',
        [],
        '1.0'
    );

    wp_enqueue_script(
        'bootstrap-js',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',
        [],
        null,
        true
    );

    wp_enqueue_script(
        'cp-app',
        CP_URL . 'assets/js/app.js',
        [],
        '1.0',
        true
    );

    wp_enqueue_script(
        'cp-users',
        CP_URL . 'assets/js/users.js',
        [],
        '1.0',
        true
    );
}

add_action('wp_enqueue_scripts', 'cp_enqueue_assets');
<div class="container-fluid">

    <h2>Categories</h2>

</div>
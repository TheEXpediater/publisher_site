Enterprise1979 Publisher Portal 3.9.2

WordPress owner account
enterpriseenteng@gmail.com

Access rules
1. enterpriseenteng@gmail.com is the only account allowed to see the native WordPress admin interface.
2. Every other logged-in account stays inside the custom Publisher Portal, including other administrator accounts.
3. Portal-only accounts are redirected away from direct WordPress admin URLs.
4. Portal-only accounts see a full-screen custom shell with no WordPress sidebar, toolbar, footer, notices, Screen Options, or Help panel.
5. Portal-only accounts are redirected to the Publisher Portal after login.
6. The front-end WordPress toolbar is hidden for portal-only accounts.
7. The owner account keeps normal WordPress access for plugins, themes, updates, settings, and maintenance.

Installation
1. Back up the current plugin and database.
2. In Plugins, upload this ZIP and replace the existing client-portal folder when prompted.
3. Activate the plugin if WordPress deactivates it during replacement.
4. Sign out and test with a portal account in a private browser window.
5. Sign in as enterpriseenteng@gmail.com and confirm the normal WordPress admin remains visible.

Changing the WordPress owner account
Add this before the WordPress stop-editing line in wp-config.php:

define('CP_WORDPRESS_ACCESS_EMAIL', 'owner@example.com');

The constant overrides the built-in default email.


Version 3.6.2 landing-page card refinement
1. Removes the repeated category badge inside landing-page section cards.
2. Keeps the outer card size, border, padding, grid, and section spacing unchanged.
3. Enlarges card images with a stable 5:4 frame and proportional cropping.
4. Rebalances headline, metadata, excerpt, and Read More spacing.
5. Applies these changes only to category cards on the site landing page.
6. Existing shortcodes remain compatible and do not need replacement.

Version 3.6.3 landing-page refinement:
- Keeps featured story copy and Read More within the featured image height on desktop/tablet.
- Clamps long featured and card text with an ellipsis.
- Equalizes landing-page section card widths and heights.
- Keeps landing images cropped proportionally with object-fit: cover.
- No shortcode changes are required.

Version 3.6.4 featured-image refinement:
- Enlarges the landing-page featured image on wide desktop screens.
- Uses one consistent maximum frame of 380 by 285 pixels with a 4:3 ratio.
- Crops mixed source-image sizes proportionally through object-fit: cover.
- Keeps the featured text and Read More aligned within the same image height.
- Leaves landing cards, archives, article pages, portal screens, and shortcodes unchanged.


Version 3.6.5 landing-page excerpt refinement:
- Lets featured and category-card excerpts use the available copy height before showing an ellipsis.
- Keeps Read More inside the existing image-height boundary.
- Uses longer source excerpts only on the landing page.
- Leaves card sizes, image proportions, archives, article pages, portal screens, and shortcode syntax unchanged.


Version 3.6.6 landing-page responsive refinement:
- Stacks the featured image and article copy cleanly on narrow screens.
- Moves About Us below the featured story on tablet-sized screens.
- Removes fixed landing-card heights on smaller screens and preserves proportional 5:4 images.
- Keeps card titles, metadata, excerpts, and Read More within responsive card bounds.
- Replaces WordPress bracketed excerpt endings with plain three dots on landing-page featured and card excerpts.
- Leaves archive pages, single articles, portal screens, and shortcode syntax unchanged.

Version 3.7.0 article-builder refinement:
- Removed Table from the standalone Content Block menu. Existing table blocks remain supported for backward compatibility.
- Added a Google Docs-style table grid picker to the Paragraph toolbar.
- Replaced the Format dropdown with Font and Font Size controls.
- Added a clean white-page editing state with block controls shown on hover or focus.
- Added safe frontend support for paragraph fonts, font sizes, and inline tables.


Version 3.8.0 administration refinement:
- Adds a desktop collapse control for the custom portal sidebar. The compact state shows navigation icons and stays saved in the browser.
- Keeps the existing mobile slide-out navigation behavior.
- Replaces the Author Publishing switch with a clean, accessible toggle and expands the Preferences panel across the available content row.
- Adds an administrator-only Activity Logs tab under Settings.
- Records successful logins, logouts, article changes, category changes, user changes, settings changes, and homepage-feature changes.
- Adds date-range and action filters, pagination, and a details modal with the affected item and recorded changes.
- Creates the activity-log database table automatically during activation or the first request after an update.


Version 3.8.1 category and administration refinement:
- Keeps category archive article copy within the same height as its proportional 4:3 image on desktop.
- Clamps long category titles and excerpts while anchoring Read More inside the image-height boundary.
- Preserves natural stacked content flow on tablets and phones.
- Reduces the sidebar collapse control visibility until the sidebar or control is hovered or focused.
- Shows 10 activity-log records per page with the existing portal-style pagination.
- Does not require shortcode changes.


Version 3.8.2 published image ratio standardization:
- Renders published article, card, featured, category, related-story, other-story, and search images in an exact 1:1 square frame.
- Uses proportional center cropping with object-fit: cover.
- Applies the square ratio to the single-article hero and article-body image blocks.
- Leaves original Media Library files unchanged.
- Leaves portal administration, article data, queries, text, and non-image functions unchanged.


Version 3.8.3 single-article image sizing refinement:
- Reduces only the single-article featured/hero image to a maximum 700 x 700 px square on desktop.
- Keeps the single-article hero responsive and square on tablets and phones.
- Changes Related Stories thumbnails to the same compact square size used by standard article cards: 78 x 78 px, and 70 x 70 px on narrow phones.
- Leaves homepage, archive, category, search, other-story, article-body, portal administration, publishing logic, queries, and Media Library files unchanged.


Version 3.8.4 single-article Related Stories refinement:
- Moves Related Stories closer to the single-article hero by matching the main grid column to the 700 px hero width.
- Keeps the existing square Related Stories thumbnails unchanged.
- Limits Related Stories headlines to two lines with an ellipsis so text stays within the thumbnail row height.
- Keeps Related Stories copy constrained to the thumbnail height on desktop and phones.
- Leaves homepage cards, category archives, search results, other stories, article-body images, publishing logic, queries, and Media Library files unchanged.


Version 3.8.5 single-article alignment refinement:
- Shifts only the single-article breadcrumb, title/meta header, and article/Related Stories grid slightly to the right on desktop while retaining a clearly left-aligned editorial layout.
- Forces Related Stories thumbnails and their category/title copy to align from the top edge of each row, including rows with short titles.
- Preserves the existing two-line Related Stories title ellipsis and square thumbnail sizing.
- Leaves homepage cards, archives, search, other stories, article-body images, publishing logic, queries, and Media Library files unchanged.


3.8.6
- Added a portal-branded Forgot Password form on the existing publisher login route.
- Password reset requests use WordPress core retrieve_password() and its secure reset tokens.
- Added non-enumerating recovery confirmation and preserved native WordPress reset validation.
- No publishing, article, category, search, media, or front-end story layout logic changed.


3.8.7
- Updates Facebook links in the About Us page and homepage About Us content to https://www.facebook.com/theenterprisehau.
- Adds Full Screen / Exit Full Screen controls to Heading and Paragraph content blocks only.
- Adds an Article Details settings button with a modal editor for the title and excerpt.
- Keeps the WordPress post title and excerpt plain for compatibility while storing safe rich formatting separately for the single-article title and deck.
- Rebuilds Heading blocks as focused rich-text editors with a dedicated H1-H6 level control and formatting toolbar.
- Leaves image sizing, cards, categories, search, publishing permissions, and Media Library behavior unchanged.

3.8.7 Author Article Library refinement
- Author accounts can browse the complete published Article Library instead of seeing only their own posts.
- Draft and private stories remain hidden from Author accounts.
- The Article Library Actions column shows only View for Author accounts.
- Editor and Administrator Article Library behavior remains unchanged.
- Article creation and all unrelated portal features remain unchanged.

3.8.8 Publisher Portal navigation, logout, login-security, and footer refinement
- Replaces the primary navigation's separate "More" dropdown with an About Us dropdown: categories beyond the first 8 now live under About Us itself (About Us stays the fixed final item and still links straight to the About Us page).
- Adds real server-rendered active-navigation state (aria-current + a white underline) for the current category and About Us, replacing the previous permanently gold-colored About Us link. Determined from WordPress's own query context (the category's own frontend Page, the taxonomy archive as a defensive fallback, or a single article's primary category), never guessed client-side or by list position.
- Connects the site footer menu to the same category source, saved order, and typography as the header (includes/nav-menu.php), via the same pre_wp_nav_menu override already used for the header - so a category created, renamed, reordered, or deleted in the Category Manager never needs separate footer maintenance. Previously the footer's menu location had no menu assigned and rendered nothing tied to the plugin's categories.
- Adds a "View Menu" action to the Category Manager: a live preview of the real header/footer navigation, with an Edit Menu mode to drag-and-drop (or use accessible Move Up/Down controls) the category order and choose a shared navigation Font Family/Font Size from the same whitelist already used by the Article Builder. Saved order and typography persist via term-ID-based options so renaming a category never loses its position.
- Fixes the Publisher Portal logout landing on wp-login.php?loggedout=true instead of /publisher-login/: the logout link's requested redirect is now explicitly re-asserted via a scoped logout_redirect filter, independent of whatever was previously causing it to be dropped. Native WordPress/wp-login.php logout behavior elsewhere is unaffected.
- Adds a live, server-timestamp-driven lockout countdown to the Publisher Login screen (mm:ss) and disables the Sign In button for the duration - the existing server-side progressive rate limiting (includes/login-rate-limit.php) already rejected every attempt during a lockout, including a correct password; this only makes the already-enforced cooldown visible and accurate across refreshes.
- No changes to article creation/editing, Article Builder, categories CRUD, Media Library behavior, analytics, activity logs, or role/capability restrictions.

3.8.9 corrective hardening pass
- Adds a missing Remove Photo control to the User Manager's profile-photo picker (previously only Choose/Change existed, with no way to clear a photo back to the default WordPress avatar). Backed by a new cp_remove_user_profile_image() that clears the stored attachment and user meta.
- Wraps the profile-photo upload path (includes/users.php: cp_handle_profile_image_upload(), and its caller in cp_handle_user_save()) in try/catch(\Throwable), so any unexpected PHP error during upload/attachment/metadata handling now returns a normal Publisher Portal warning notice instead of a possible white-screen critical error. Direct source review found no reproducible fatal in this version's upload implementation (it already required the correct wp-admin/includes files and checked every WP API call for WP_Error/failure); this closes the gap between "no defect found by static review" and "cannot fatal," which static review alone cannot guarantee.
- Makes the footer navigation's Astra "footer_menu" placeholder menu assignment reversible: deactivating the plugin now unassigns that location if it still points at the plugin's own auto-managed placeholder menu, so a deactivated plugin doesn't leave an empty menu location wired into the live theme footer.
- No other behavioral changes; this pass is corrective verification of 3.8.8, not a rewrite.

3.8.10 login lockout duration correction
- Fixes the 3rd-failed-login lockout duration: it was 1 minute, which let a correct password through again well inside the required window. The 3rd consecutive failure now locks for 5 minutes.
- Escalation for repeated abuse past the first lock: 6 failures -> 30 minutes, 9 -> 3 hours, 12+ -> 24 hours (was 5 min / 30 min / 3 hours).
- No other change: identifier/IP keying, the separate IP-wide guard, generic non-enumerating error messages, transient-based persistence, nonce handling, and native/owner WordPress authentication are all unchanged.

3.8.11 live bug-fix pass
- Fixes "About Us" wrapping to a second row in the Category Manager's View Menu / Edit Menu preview: the header preview's flex row inherited the live header's flex-wrap: wrap, which is correct at full site width but wrapped in the modal's narrower preview area. Scoped entirely to the admin preview (assets/css/category-menu-editor.css) - forces one row and compacts item padding there only; the live frontend header (assets/css/frontend-navigation.css) is untouched.
- Adds a confirmation step before the menu editor's Save actually persists ("Save menu changes?"), reusing the portal's existing shared confirm dialog (assets/js/app.js gained a small additive cpConfirmAction() API alongside its existing declarative confirm triggers - nothing existing was changed). Cancel leaves Edit Menu mode with unsaved edits intact and sends no request.
- Adds a visible in-modal success/error notice after Save: a green "Menu updated successfully" (using the server's actual response, not assumed client state) or a red "Unable to save menu changes" - and the Save button is disabled for the duration of the request to prevent double submission.
- Login rate limiter: re-traced and source-simulated the full failure #1/#2/#3/locked-attempt/expiration/successful-login sequence against the current code; the 3rd-failure lock (and the same-response countdown) is already correct as of 3.8.10's duration fix. Added targeted debug-log breadcrumbs (includes/login-rate-limit.php, active only when WP_DEBUG is enabled) at the lock check, the failure-count bump, and a same-request lock-write readback verification, so if this remains invisible on a live install after deployment, the actual cause (e.g. a non-persistent object cache silently dropping the transient write) is diagnosable from the PHP error log instead of unobservable. No logic changed in this file beyond the added logging.

3.8.12 category + navigation UX pass
- Fixes a category rename (e.g. WordPress's original "Uncategorized" category renamed to something else) still showing the old name on its frontend category page: the mapped Page's own post_title was set once when the Page was first provisioned and never kept in sync on a later rename. cp_handle_category_save() now syncs the Page title (only the title - never the URL/slug) whenever a rename is detected. The category's term ID, its Page mapping, and every article already assigned to it were never affected by this bug (a rename never changes a term's ID or its post associations) - only the WordPress Page's own displayed title was stale.
- Corrects the header navigation's top-level item count: it was showing 8 categories plus About Us (9 total). The limit is now 7 direct categories + About Us = 8 top-level items total, via the single shared CP_NAV_MAX_VISIBLE_CATEGORIES constant (now 7, was 8) that every renderer (public header, admin preview, menu editor) already read from. Category #8 onward now correctly falls inside the About Us dropdown. The footer is unaffected - it was never subject to this cap and continues to show every active category in a flat row.
- Redesigns Edit Menu into separate Header and Footer tabs, each with its own live preview, Font Family/Font Size, and drag-or-arrow-button reordering - switching tabs preserves the other tab's unsaved edits, and one Save Changes action persists both. Header and footer now have independent saved order/typography (includes/nav-menu.php: new per-surface options), while both still resolve every item through the same "category" taxonomy term IDs - no category data is duplicated. Existing installs are migrated automatically: until a surface's own settings are explicitly saved, it falls back to reading the pre-existing shared order/typography, so nothing resets on upgrade.
- Centers both navigation previews in the Category Manager's View Menu / Edit Menu modal (scoped to the admin preview only; the live public header's own left-aligned-categories/right-pushed-About-Us layout is unchanged).
- Fixes the public footer navigation text rendering gray instead of white - scoped to the plugin's own footer nav (#cp-footer-navigation) so no other footer link on the site is affected; hover/focus/current states remain distinguishable.
- About Us dropdown active state: when a category inside the overflow dropdown (position 8+) is the current page, the toggle now shows a small indicator dot that a child section is active, without ever marking the About Us link itself as aria-current - that remains true only on the actual About Us page.
- Investigated the reported Category Manager "Edit shows Add Category" issue: traced templates/categories.php and assets/js/categories.js end to end (trigger click -> setEditMode() -> title/button text/field population) and found the existing implementation already sets Edit-mode text and populates existing name/slug/description/ID correctly, with no code path found that falls back to Add-mode text while editing. Left unchanged - no defect found to fix.

3.8.13 category confirmation dialog + login limiter diagnostics
- Fixes the category Add/Edit confirmation dialog showing a mismatched Add title and Add button label alongside a correctly Edit-worded message. Root cause: assets/js/categories.js's refreshConfirmMessage() only ever updated the dialog's message attribute (data-cp-confirm) based on the current mode; the title and button-label attributes (data-cp-confirm-title, data-cp-confirm-label) were left exactly as PHP rendered them on the initial page load - which is Add-mode text, since the page normally loads with no category being edited - and were never updated again when switching into Edit mode. All three attributes are now kept in sync with the actual add/edit state together.
- Login rate limiter: re-traced and re-simulated the full failure #1/#2/#3/locked-attempt/correct-password-while-locked/expiration/successful-login sequence once more; found no logic defect (identifier-key derivation is identical across the lock check, the failure increment, and the post-login clear; the 3rd failure produces and returns a lock exactly 300 seconds in the future within the same response). Added explicit lifecycle debug-log breadcrumbs across every branch of cp_process_custom_login() (WP_DEBUG-gated, includes/custom-login.php) - including the nonce-check and empty-credentials early-exit paths - so a live trace can show definitively whether a submission is even reaching the rate limiter at all (e.g. a page cache serving a stale/expired nonce to every visitor would look identical to "the limiter doesn't work" from the outside while never actually running it, and would now be visible as a distinct "REJECTED at nonce check" log line instead).
- No third-party security plugin added; the custom limiter is unchanged in its actual lockout logic.

3.9.0 Pages + About Us + Staff feature release
- Adds a new Page Manager (includes/pages.php, templates/pages.php), reached via a "Pages" button next to the existing Category Manager controls, restricted to the manage_options capability. Manages real WordPress Pages - never a parallel/custom page system - with Active/Inactive mapped to publish/draft, a compact View link, and Edit/Delete (Trash) actions. The Home page (resolved from the site's actual show_on_front/page_on_front configuration) is always listed first and can never be deleted from this screen; the configured About Us parent page is protected from deletion while it remains the navigation parent.
- Adds a small, purpose-built Page Builder (includes/page-builder.php, templates/page-builder.php, assets/js/page-builder.js) for standalone institutional pages: Heading, Rich Text, Image, Staff Grid, Button/CTA, and Divider/Spacer blocks, with drag-and-drop plus keyboard Move Up/Down reordering, duplicate/remove, Media Library image selection, and the same Save-confirmation pattern already used elsewhere in the portal. Reuses the Article Builder's existing rich-text sanitizers and font whitelist rather than introducing a second content-sanitization stack; only whitelisted HTML/typography is ever persisted.
- About Us is now explicitly a WordPress Page (never a category taxonomy term) with its own designated "parent" option; managed child Pages (Staff, Join the Publication) can be flagged to appear in the About Us dropdown with their own saved order, editable via Move Up/Down controls in the Page Manager table.
- The header's About Us dropdown now shows two clearly separated groups when needed - "Pages" (managed Pages such as Staff/Join) and "More Sections" (category position 8+, the existing overflow behavior, fully preserved) - sourced from two independent lists (Page IDs vs. category term IDs) that are never merged into one ambiguous data source. Active-state detection now also recognizes a managed Page as the current item without ever falsely marking About Us itself as current.
- Seeds (idempotently - safe to run repeatedly, never duplicates) the initial About Us content from "ABOUT US - THE ENTERPRISE.docx" (About the Publication, Brief History) and a new Join the Publication page (Membership Requirements and Procedures, with the actual supplied Google Form as its CTA button) from the same document, and a new Staff page seeded from "MASTERLIST WITH PORTRAITS OF ENTENG.docx" (26 people across Editorial Board, Editorial Staff, and Reportorial Staff, grouped per the project's own authoritative breakdown). No portraits were supplied, so every staff card renders a neutral decorative placeholder until an administrator uploads a real one.
- The Staff Grid renders in responsive rows of up to six cards (assets/css/frontend-pages.css): 1-3 people keep a normal capped width and center as a group rather than stretching; 4-6 use an even grid that fills the section width so cards enlarge as the row fills; a trailing partial row is always centered. Entirely data-driven from the saved people list - no hardcoded names, counts, or per-person coordinates.
- The existing About Us WordPress Page (previously rendering a non-functional `[enterprise_maintenance]` shortcode via a leftover Elementor configuration) is taken over by the new Page Builder on first run; its Elementor-specific and page-builder-layout post meta is cleared only the first time it's migrated, and only for this one page - Elementor itself, and every other page on the site, is untouched.
- No changes to category CRUD, article CRUD/Article Builder, the login limiter, logout redirect, password reset, user avatars, or analytics.

3.8.14 login rate limiter architecture fix (proven via live SSH diagnostics)
- Fixes the actual proven root cause of the login limiter never visibly locking out on the live site: the failure counter was keyed by normalized-login + REMOTE_ADDR together, and REMOTE_ADDR was observed to change between consecutive requests from the same real visitor on the live Hostinger runtime - silently resetting the counter to 1 before it ever reached 3.
- Splits the limiter into two fully independent tracks: an ACCOUNT limiter keyed only by the canonical account being attempted (never the client address, so it now counts correctly regardless of address instability), and the existing SOURCE/IP guard kept as a separate defense-in-depth limiter. A login is blocked if either is active; the more restrictive expiration is shown.
- Canonicalizes the account key: whether the admin types their username or their email, both now resolve (via get_user_by(), used only internally to derive the limiter key - never exposed in any response) to the same WordPress user ID, so alternating between username and email no longer resets the count. An identifier that matches no account still gets its own stable key, so the limiter works the same way against guessed/fake usernames.
- Account keys are now HMAC-SHA256'd with WordPress's own auth salt (wp_salt()) rather than a plain hash, so a key can't be precomputed from a guessed email address without server-side secrets.
- Renamed the internal key-generation functions for clarity (cp_login_rate_limit_identifier_key() -> cp_login_rate_limit_account_key(), cp_login_rate_limit_ip_key() -> cp_login_rate_limit_source_key()); the public functions custom-login.php calls (cp_login_rate_limit_is_locked(), cp_login_rate_limit_record_failure(), cp_login_rate_limit_clear()) kept the same names and behavior contract.
- Removed the verbose per-request lifecycle diagnostics added in 3.8.13/3.8.13's follow-ups now that the live root cause is proven and fixed; retained only production-appropriate logging (an account lock being created, and a request being blocked by an active lock), gated behind WP_DEBUG as before.
- Verified live on the production Hostinger environment via SSH (deployed, then tested with 3 deliberately wrong-password submissions against the real owner account, cleared afterward): account fail count went 1 -> 2 -> 3 across requests made from this session's own network path (independent of the live site's original REMOTE_ADDR instability), the 3rd failure produced a lock exactly 300 seconds out (data-cp-lockout-until returned in that same response), and a 4th request during the lock was confirmed blocked before wp_signon() (fails count stayed at 3, the existing lock timestamp was preserved unchanged) via both the HTTP response and direct wp-cli transient inspection.

3.9.1 Pages admin + About Us UI hotfix pass (live bug-fix, proven via SSH diagnostics)
- Fixes the Pages admin screen (cp-pages) rendering completely blank. Root cause, proven live via wp eval: the template file was named "pages", and WordPress core's own sanitize_file_name() silently rewrites any bare filename matching a registered MIME-type extension - "pages" collides with the built-in application/vnd.apple.pages (Apple Pages) type - to "unnamed-file.pages", which cp_render_template() then can't find, triggering a wp_die() with no visible cause. Renamed templates/pages.php to templates/page-manager.php (a name that does not collide with any registered MIME extension) and updated cp_pages_page() (includes/pages.php) to render it; no other change to the Page Manager's logic, markup, or capability check.
- Fixes the About Us/Join the Publication CTA button rendering invisible (no background, no visible text). Root cause, proven live via curl: frontend-pages.css styles the CTA (and the rest of the managed-page layout) entirely through the --enterprise-brand/-ink/-serif/-sans custom properties defined in frontend.css, but frontend.css was never enqueued on a plain managed Page (only on the category-archive/article shortcodes) - so every var(--enterprise-*) reference silently fell back to nothing rather than erroring. cp_enqueue_frontend_page_styles() (includes/page-builder.php) now enqueues frontend.css as an explicit dependency of frontend-pages.css.
- Removes the "Pages" group label above the managed-Page links inside the About Us dropdown (includes/frontend-navigation.php) per updated design direction - the Pages (Staff, Join the Publication, etc.) now list directly under About Us with no heading; the "More Sections" label for overflow categories (position 8+) is unchanged and still only ever appears when an overflow category actually exists.
- Adds Header/Footer tabs to View Menu mode in the Category Manager's navigation-preview modal (templates/categories.php, assets/js/categories.js), matching the tab pattern already used by Edit Menu mode (same .cp-menu-editor-tab/-tab-panel markup, role="tablist"/role="tab"/aria-selected semantics, Header shown by default) - replacing the previous stacked header-then-footer scrolling layout so only one preview is visible at a time.
- Fixes the About Us dropdown being clipped inside the View/Edit Menu preview: .cp-menu-editor-preview (assets/css/category-menu-editor.css) had overflow-x: auto with overflow-y left unset, which per the CSS spec forces the y-axis to also compute as auto - clipping the dropdown, an absolutely-positioned element that extends below the preview box, into a scrolled region the moment it opened. Changed to overflow: visible; the header-fits-on-one-row fix from 3.8.11 (flex-wrap: nowrap + compacted item padding) already makes the previous horizontal-scroll safety net unnecessary at this modal's width.
- No changes to category CRUD, article CRUD/Article Builder, the login limiter, logout redirect, user system, or analytics.

3.9.2 Pages + navigation live QA fix (proven via SSH diagnostics)
- Fixes a legacy "About Us" category term (ID 26, slug about-us, 0 attached posts - confirmed via direct database inspection before any change) left over from the pre-Pages-feature architecture, still showing in the Category Manager table. Added an exact-slug reserved-identity check (cp_is_reserved_about_us_category(), includes/categories.php) that excludes it from the Category Manager's listing/count and from every navigation category source (includes/nav-menu.php), and rejects any attempt to create or rename a category to the reserved "about-us" identity with an explicit error ("About Us is managed as a Page and cannot be created as an article category.") rather than silently renaming or allowing the conflict. The orphaned term itself (verified zero article associations via a direct term_relationships query) was then removed via WordPress's own taxonomy API after recording its data, per the zero-posts-safe-to-remove case; live article categories/counts are otherwise completely untouched.
- Fixes the About Us Page's Active/Inactive status not actually controlling public visibility: setting it Inactive (draft) correctly wrote post_status=draft, but the header/footer nav renderers (includes/frontend-navigation.php) never checked it before printing the About Us link and its whole dropdown. Added cp_about_us_is_publicly_visible() (true only when the resolved About Us Page is actually post_status=publish) and gated the entire About Us top-level item - link, toggle, and dropdown (managed Pages and overflow categories alike) - on it in both cp_render_primary_navigation_markup() and cp_render_footer_navigation_markup(). Reactivating it (publish) immediately restores the item on the next page load, since this reads the Page's real status directly rather than a separate cached flag. Child-Page (Staff, Join, etc.) status filtering was re-verified and was already correct - cp_get_about_nav_pages() already re-queries post_status=publish for every ID on each render rather than trusting the stored order array's membership alone.
- Removes the redundant Astra theme-generated page title/heading (e.g. a floating "Staff" above the Page Builder's own "Our Staff" heading) from every plugin-managed Page. Traced to Astra's own documented per-post "Disable Title" integration point (the "site-post-title" post meta, set to "disabled" - wp-content/themes/astra/inc/metabox/class-astra-meta-boxes.php on this install; no Astra filter override, no theme file edited, no Elementor involved). Added cp_suppress_theme_page_title() (includes/pages.php), called from the Page Manager's save path for every future managed Page, and from the idempotent seed migration (includes/page-seed.php, seed version bumped 1 -> 2 to apply this retroactively to the already-existing About Us/Staff/Join the Publication pages without re-seeding their content). Unrelated WordPress Pages are completely unaffected - the meta is only ever set for a Page this plugin actually manages.
- View Menu preview links (Categories -> View Menu, both Header and Footer tabs) no longer navigate away from the Publisher Portal when clicked - a single delegated click-interceptor scoped to .cp-menu-editor-preview elements inside the modal (assets/js/categories.js) stops any link activation there, while the About Us dropdown toggle button (not a link) keeps working exactly as before. Reordered View Menu's content so the actual navigation preview is featured first, with the explanatory helper text moved below it as subdued text rather than displacing the preview - Header/Footer tabs, single-preview-at-a-time behavior, and the dropdown-clipping fix from 3.9.1 are all unchanged.
- Adds a Settings gear next to the Page Manager's heading (Manage Pages), opening a new "About Us Navigation" modal: a live preview of the About Us dropdown plus a Page Order list supporting drag-and-drop and keyboard Move Up/Down (assets/js/page-manager.js, reusing the Category Menu Editor's own .cp-menu-editor-item/-move-btn interaction chrome for a consistent feel), a confirmation step before saving ("Update About Us Navigation - Save this page arrangement?"), and success/failure feedback from the actual server response. Only active (published), About-Us-flagged managed child Pages are shown as draggable; any currently Inactive one is listed separately and clearly marked as not publicly visible, and an inline notice appears if About Us itself is currently Inactive. Persists to the existing cp_about_pages_order option by Page ID only (cp_save_about_nav_order(), includes/pages.php), validated server-side against real current eligibility on every save - never trusting submitted IDs blindly, and never losing a currently-Inactive Page's stored position just because it wasn't part of the draggable submission.
- No changes to category CRUD, article CRUD/Article Builder, the login limiter, logout redirect, user system, or analytics.
